import "./App.css";
import { Route, Routes } from "react-router-dom";
import Home from "./component/Home/Home";
import Header from "./component/Header/Header";
import Footer from "./component/Footer/Footer";
import About from './component/About/About';
import Contact from "./component/contact/Contact";
function App() {
  return (
    <>
    
    <div className="App flex flex-col min-h-screen">
      <Header />
      <div className="content flex-grow   ">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </div>
      <Footer />
    </div>
    </>
    
  );
}



export default App;
