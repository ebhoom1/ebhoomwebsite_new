import React from 'react';

function Subscription() {
  
  return (
    <div>
<div className='py-10'></div>
      <h1 className='mt-5 text-center'></h1>
      <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSeXaXPvWBH-9kDXVRieJDvEEhM93QXlDZJ303n4V2AmDe2iVw/viewform?embedded=true" width="100%" height="800" frameborder="0" marginheight="0" marginwidth="0" style={{ border: 'none' }}
        title="Subscription Form"
>Loading…</iframe>
    </div>
  );
}

export default Subscription;
